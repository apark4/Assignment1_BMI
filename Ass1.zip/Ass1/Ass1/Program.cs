﻿using System;

namespace Ass1
{
    class Program
    {
        static void Main(string[] args)
        {
            //declare variables
            double weight,bmi;
            int height;
            string name;

            //prompt user for weight,height name
            Console.Write("Please enter your name: ");
            name = Console.ReadLine();
            Console.Write("Hello " + name + ", please enter your weight in lbs: ");
            weight = Convert.ToDouble(Console.ReadLine());
            Console.Write(name + ", please enter your height in inches: ");
            height = Convert.ToInt32(Console.ReadLine());

            //calculate bmi
            bmi = weight / (height*height) * 703;

            //display if person is underweight,normal,overweight,obese
            if(bmi < 18.5)
            {
                Console.WriteLine(name + ", your bmi is " + bmi + " and underweight");
            }
            else if(bmi < 25)
            {
                Console.WriteLine(name + ", your bmi is " + bmi + " and normal");
            }
            else if(bmi < 30)
            {
                Console.WriteLine(name + ", your bmi is " + bmi + " and overweight");
            }
            else
            {
                Console.WriteLine(name + ", your bmi is " + bmi + " and obese");
            }
            
        }
    }
}
